let arreglo=['daniel','laura','camilo']

console.log(arreglo)

arreglo.push('sofia')//agrega en la ultima

arreglo.pop(arreglo)//quita el ultimo

arreglo.unshift('sergio')//agrega en la 1


arreglo.shift()//quita el 1

function algo(x){
    let res=1
    for(let i=0;i<x;i++){
        res=res*2
    }
    return res
}
console.log(algo(4))

function algo2(x,y){
    return x===y
}
console.log(algo2(1,'1'))

arreglo.unshift('hola')
arreglo.shift()
console.log(arreglo)