for(var i=0;i<10;i++){
    console.log(i)    
}

var a=-5
while(a!==0){
    console.log(a)
    a++
}

var frutas=['manzana', 'pera', 'uva']
for(var i=0;i<frutas.length;i++){
    console.log(frutas[i])
}

//for of for in
for(var i in frutas){ //retorna el index
    console.log(frutas[i])
}

for (var i of frutas){ //retorna valores
    console.log(i)
}

var objeto={
    clave1: 'valor1',
    clave2: 'valor2',
    clave3: 'valor3',
}

for(var i in objeto){
    console.log(i)
}
//error por objeto no iterable
//for(var i of objeto){
  //  console.log(i)
//}

//ES6+
var a=5//alcance de bloque, definidos por {}
let c=7 //alcance local
const b=6 //valor constante, alcance local
d=8 //alcance global

//----------
function miFuncion(){
    return 'funcion clasica'
}

const miFuncion2 = function(){
    return 'guardando funcion clasica'
}

const miFuncion3=() => {
    return 'arrow function'
}

const miFuncion4 = () => 'arrow function retorno directo'
console.log(miFuncion4())

//scope

const funcionCualquiera=()=>{
    if(true){
        var variableVar='var' //mala practica
        let variablelet='let' //utilizar esta
        const variableConst='const' //o esta
        variable='solo variable' //MALA PRACTICA
    }
    console.log(variableVar)
}

funcionCualquiera()
console.log(variable)

const accion=()=>console.log('soy una accion')

const otraFuncion=() =>{
    setTimeout(()=>{
        console.log('funcion anonima')}
        ,2000)
}

const otraFuncion2 =() =>{
    for(var i=0;i<10;i++){
        setTimeout( ()=> console.log(i),2000)
    }
}
otraFuncion2()
console.log(otraFuncion2)






const operar=(tipo,a,b)=>{
    switch(tipo){
        case 'suma': const suma=(a,b)=>a+b; return suma(a,b)
        case 'resta': const resta=(a,b)=>a-b; return resta(a,b)
        case 'multi': const multi=(a,b)=>a*b; return multi(a,b)
        case 'division': const division=(a,b)=>(a/b).toFixed(5); return division(a,b)
    }
}
console.log(operar ('suma',5,6))
console.log(operar ('resta',5,6))
console.log(operar ('multi',5,6))
console.log(operar ('division',5,6))

